function function1() {
    fetch("https://randomuser.me/api/?results=50")
        .then((dataFromApi) => { return dataFromApi.json(); })
        .then((dataAsObj) => {
            //console.log(dataAsObj.results);
            for (const curr of dataAsObj.results) {
                // console.log(curr.name.first);
                console.log(curr.login.username);

                // create "currCard" div
                let currCard = document.createElement("div");

                // create img
                let imgElement = document.querySelector("img");

                // set the src attribute to the curr.picture.large value
                imgElement.setAttribute("src", curr.picture.large);

                // add the img to "currCard" div
                currCard.appendChild(imgElement);

                // create new h3 with the curr username
                let myNewH3 = document.createElement("h3");
                myNewH3.textContent = `${curr.name.first} ${curr.name.last}`;

                // add the new h3 on the "currCard" div 
                currCard.appendChild(myNewH3);

                // create p element for the email and add it to currCard


                // add the "currCard" div to screen inside myDiv
                document.querySelector("#myDiv").appendChild(currCard);
            }

        })
}