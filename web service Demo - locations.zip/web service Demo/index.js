function example1() {
    const theUrl = "https://class-examples.onrender.com/exam/locations";
    fetch(theUrl)
        .then((dataFromApi) => { return dataFromApi.json() })
        .then((dataAsObj) => {
            console.log(dataAsObj);

            const cleanArrOfLocations = dataAsObj.locations.slice(1);

            for (const curr of cleanArrOfLocations) {
                const theCurrLocationDiv = document.createElement("div");
                // add class so we'll be able to style it using css
                theCurrLocationDiv.classList.add("locationCard");

                // adding h3 with Name of location
                const theCurrLocationH4 = document.createElement("h3");
                theCurrLocationH4.textContent = curr.Name;
                theCurrLocationDiv.appendChild(theCurrLocationH4);


                // adding h5 with Region of location
                const theCurrLocationH5 = document.createElement("h5");
                theCurrLocationH5.textContent = curr.Region;
                theCurrLocationDiv.appendChild(theCurrLocationH5);

                // adding h5 with LAT of location
                // const theCurrLocationH5_LAT = document.createElement("h5");
                // theCurrLocationH5_LAT.textContent = curr.LAT;
                // theCurrLocationDiv.appendChild(theCurrLocationH5_LAT);

                // adding h5 with LON of location
                // const theCurrLocationH5_LON = document.createElement("h5");
                // theCurrLocationH5_LON.textContent = curr.LON;
                // theCurrLocationDiv.appendChild(theCurrLocationH5_LON);

                // create input button with text "display on map"
                const showMapBtn = document.createElement('input');
                showMapBtn.setAttribute('type', 'button');
                showMapBtn.setAttribute('value', 'display on map');
                showMapBtn.style.display = 'block';
                //   add two "attributes" : lat lon
                //        with values of the LAT LON of the location
                showMapBtn.setAttribute('lat', curr.LAT);
                showMapBtn.setAttribute('lon', curr.LON);
                // add event listener to the button click event
                //  in the function get the map's src attribute and change it
                //    using the interpulation str:
                //  `https://www.openstreetmap.org/export/embed.html?bbox=${lat}%2C${lon}%2C${lat}%2C${lon}&layer=mapnik&marker=${lat}%2C${lon}`;
                //     get the values for the lat lon from the "attributes of the button"
                //         (use event.target)
                showMapBtn.addEventListener('click', (event) => {
                    const theMapIframe = document.querySelector("#mapDiv iframe");
                    // const lat = event.target.getAttribute('lat');
                    // const lon = event.target.getAttribute('lon');
                    const lat = curr.LAT;
                    const lon = curr.LON;

                    //  OpenStreet map
                    theMapIframe.setAttribute('src',
                        `https://www.openstreetmap.org/export/embed.html?bbox=${lat}%2C${lon}%2C${lat}%2C${lon}&layer=mapnik&marker=${lon}%2C${lat}`);


                    // Google map
                    // theMapIframe.setAttribute("src", `https://www.google.com/maps?q=${curr.LAT},${curr.LON}&z=15&output=embed`);
                });

                theCurrLocationDiv.appendChild(showMapBtn);




                // adding a with URL (website) of location
                const theCurrLocationA_URL = document.createElement("a");
                theCurrLocationA_URL.textContent = "go to website";
                theCurrLocationA_URL.setAttribute('href', curr.URL);
                theCurrLocationA_URL.setAttribute('target', "_blank");
                theCurrLocationDiv.appendChild(theCurrLocationA_URL);


                document.querySelector("#theLocations").appendChild(theCurrLocationDiv);
            }

        })

}